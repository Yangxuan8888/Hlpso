README.txt
============================================================

## DATA AND CODE FOR: Enhanced Level-Based Learning Swarm Optimizer with Hierarchical Exemplar Selection for a Three-Phase Rectifier Control System

**Last updated:**  2025-09-10

**Corresponding Author:** [Leicheng Bai], [baileicheng@xj.cee-group.cn]

### DESCRIPTION

This repository contains the dataset and analysis code for the manuscript titled "Enhanced Level-Based Learning Swarm Optimizer with Hierarchical Exemplar Selection for a Three-Phase Rectifier Control System".
The data and code provided can be used to reproduce the main findings and figures of the study.

### FILE LIST

- `data/`: Folder containing all raw and processed data.
  - `results.mat`: Raw output from the simulation.
- `code/`: Folder containing analysis scripts.
  - `modified LLSO.m`: Main MATLAB script to run all analyses and generate figures.
- `README.txt`: This file.

### INSTRUCTIONS

To reproduce the results, run the `modified LLSO.m` script in MATLAB (version R2021b or later).
All necessary data is located in the `data/` folder and will be loaded automatically by the script.

============================================================