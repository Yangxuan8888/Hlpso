% Get_Omega.m
function w=Get_Omega(wMax, wMin, ger, Gmax)
    w=wMax-ger*(wMax-wMin)/Gmax;
end
