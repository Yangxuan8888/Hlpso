% expFunc.m
function f=expFunc(E2, K1, K2)
    f=K1.*exp(-E2./K2);
end
