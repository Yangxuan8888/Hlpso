% evaluation.m

function [fit]=evaluation(K1, K2, K3, K4, K5, K6, Vref, PCTvst, Ns, t, vol, id, iq)
    len=size(t, 1);

    %% ST
    ub=Vref+Vref*PCTvst;
    lb=Vref-Vref*PCTvst;
    flag=1;
    ST_Index=len;
    ST=t(len);
    for ii=1:len
        if flag && vol(ii)<=ub && vol(ii)>=lb
            ST=t(ii);
            ST_Index=ii;
            flag=0;
        elseif vol(ii)>=ub || vol(ii)<=lb
            ST_Index=len;
            ST=t(len);
            flag=1;
        end
    end
    
    %% OV
    delta=max(vol)-Vref;
    if delta>0
        OV=delta;
    else
        OV=0;
    end

    %% SSE
    SSE=sum((vol(len-Ns+1:len, 1)-Vref).^2);

    %% AId
    AId=mean(id(len-Ns+1:len));

    %% AIq
    AIq=mean(iq(len-Ns+1:len));

    %% indicator
    f1=expFunc(ST, K1, K2);
    f2=expFunc(OV, K3, K4);
    f3=expFunc(SSE, K5, K6);
    % Final fitness value (minimization problem)
    fit = -(f1 + f2 + f3); % 适应度函数修改为最小化问题，通过取负值进行处理
     % Ensure fitness is not NaN
    if isnan(fit)
        fit=1;
    end
    disp(['[ST, OV, SSE, f1, f2, f3, fit]=[', num2str(ST) ', ' num2str(OV) ', ' num2str(SSE) ', ' num2str(f1) ', ' num2str(f2) ', ' num2str(f3) ', ' num2str(fit) ']']);
end
