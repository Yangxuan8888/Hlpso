% LLSO.m
clc;                                                            % 清除命令行窗口
clear;                                                          % 清除所有variable
close all hidden;                                               % 关闭所有figure(visible and hidden)
format long;                                                    % 设定数据显示格式
% % 开始记录输出到 result_log.txt
%% 参数设置
c1_L=1e5;
c1_U=2e5;c_L=4.5;
c_U=6;
k1_L=7e6;
k1_U=1e8;
k0_L=8e9;
k0_U=3e10;

mdl='AC_DC20220307';
Vref=750;
Ns=500;
PCTvst=0.02;

K1=50;
K2=0.1;
K3=50;
K4=70;
K5=50;
K6=550;
kp1_base=0.1;
ki1_base=10;
kp2_base=10;
ki2_base=22;

% Initialize LLSO
N = 20;                                                   % initialize population
Gmax = 1000;                                              % maximum iterations
plimit = [0.0001,50;0.0001,50;0.0001,50;0.0001,50;0.0001,50;0.0001,50];         % position limit
% 从 plimit 定义位置上下界 (确保是 1xD 行向量)
x_lb = plimit(:, 1)';
x_ub = plimit(:, 2)';

D = size(plimit, 1);                                      % dimension: alpha, h
NL = 4;                                                  % number of levels
phi = 0.4;                                               % control parameter
run_times = 1;
% rand('state', sum(100*clock));
rng("default");
rng("shuffle");
%记录运行时间
tic;

%% 迭代开始
for kk = 1:run_times
    disp(['runtimes = ', num2str(kk)]);
    disp(['generation = ', num2str(1)]);

    %% 初始化
    for ii = 1:D                                              % initialize position (N*d)
        x(:, ii) = plimit(ii, 1) + (plimit(ii, 2) - plimit(ii, 1)) * rand(N, 1); 
    end
    v = rand(N, D);                                           % initialize velocity
    PBest = x;                                                % 每个粒子的历史最优位置
    % 初始化 PBestVal 为无穷大，表示每个粒子的历史最优适应度（将来会被更新）
%     PBestVal = inf(N, 1);  % 每个粒子都有一个适应度值，初始化为无穷大
    GBestVal = inf;                                          % Gbest
    GBest = zeros(1, D);  
    % 初始化fit为列向量
    fit = zeros(N, 1);  % 确保 fit 是一个列向量
    
    for ii = 1:N
        kp1 = x(ii, 1);
        ki1 = x(ii, 2);
        kp2 = x(ii, 3);
        ki2 = x(ii, 4);
        kp3 = x(ii, 5);
        ki3 = x(ii, 6);
        set_param([mdl '/VOL/Discrete PID Controller3'], 'P', num2str(kp1));
        set_param([mdl '/VOL/Discrete PID Controller3'], 'I', num2str(ki1));
        set_param([mdl '/CIL/Discrete PID Controller1'], 'P', num2str(kp2));
        set_param([mdl '/CIL/Discrete PID Controller1'], 'I', num2str(ki2));
        set_param([mdl '/CIL/Discrete PID Controller2'], 'P', num2str(kp3));
        set_param([mdl '/CIL/Discrete PID Controller2'], 'I', num2str(ki3));
        disp(['[kp1, ki1, kp2, ki2, kp3, ki3]=[', num2str(kp1) ', ' num2str(ki1) ', ' num2str(kp2) ', ' num2str(ki2) ', ' num2str(kp3) ', ' num2str(ki3) ']']);
        
        sim(mdl);
        t = simout1.time(:, 1);                                                                 % get simulation time
        vol = simout1.signals.values(:, 1);                                                     % get load voltage simulation data 
        id = simout2.signals.values(:, 1);                                                     % get inductance current simulation data   
        iq = simout3.signals.values(:, 1);                                                     % get inductance current simulation data   
        fit(ii) = evaluation(K1, K2, K3, K4, K5, K6, Vref, PCTvst, Ns, t, vol, id, iq);   
        disp('=================================================================================');
    end
    PBestVal = fit;
    if GBestVal > min(PBestVal)                 % 寻找全局最优解(种群历史最佳适应度小于当代个体适应度的最大值, 则更新)
        [GBestVal, index] = min(PBestVal);      % 更新群体历史最佳适应度
        GBest = PBest(index, :);            % 更新群体历史最佳位置
    end
    % 记录第一代GBestVal
    record_GBestVal_llso(kk, 1) = GBestVal;
        
    %%  层级间学习
    % 第一层的粒子保持不变
    diver = zeros(Gmax, 1);  % 用于记录每一代的多样性
    diver(1) = calculateDiver(x,plimit);
   
    for ger = 2:Gmax
        disp(['generation = ', num2str(ger)]);

        %% 分层更新粒子，升序
        particles = [x fit]; %确保fit是一个列向量
        particles = sortrows(particles, D + 1);
        x = particles(:, 1:D);
        fit = particles(:, D + 1);

        % 分层处理
        levels = cell(NL, 1);
        level_size = ceil(N / NL);
        % 将粒子分配到层级中
        start_idx = 1;
        for i = 1:NL
            end_idx = min(start_idx + level_size - 1, N);
            level_indices{i} = start_idx:end_idx; % 存储每个层级在全局 x, v, fit 数组中的索引范围
            start_idx = end_idx + 1;
        end
      
        %% 从第 NL 层到第 2 层进行更新
        for i = NL:-1:2     
            % 获取当前层级的全局索引范围
            current_level_global_indices = level_indices{i};
            % 遍历当前层级中的每一个粒子（使用其全局索引）
            
             % 遍历当前层级中的每一个粒子（使用其全局索引）
            for particle_global_idx = current_level_global_indices

                % 获取当前粒子信息
                current_x = x(particle_global_idx, :);
                current_v = v(particle_global_idx, :);
                current_fit = fit(particle_global_idx); % 获取当前粒子的适应度

                 % **从更优的层级中随机选择两个榜样 (Exemplars)**
                % SelectTwoLevels(i-1) 从层级 1 到 i-1 中选择两个层级的索引
                [rl1, rl2] = SelectTwoLevels(i-1);
    
                % 获取榜样层级的全局索引范围
                exemplar_level_indices1 = level_indices{rl1};
                exemplar_level_indices2 = level_indices{rl2};
    
                % 从选定的榜样层级中随机选择一个粒子（获取其全局索引）
                exemplar_global_idx1 = exemplar_level_indices1(randi(length(exemplar_level_indices1)));
                exemplar_global_idx2 = exemplar_level_indices2(randi(length(exemplar_level_indices2)));
    
                % 获取榜样的位置信息
                exemplar1_pos = x(exemplar_global_idx1, :);
                exemplar2_pos = x(exemplar_global_idx2, :);
    
                % 以 50% 的概率交换两个榜样的位置，增加多样性
                if rand < 0.5
                    temp = exemplar1_pos;
                    exemplar1_pos = exemplar2_pos;
                    exemplar2_pos = temp;
                end
                new_v = rand(1, D) .* current_v + rand(1, D) .* (exemplar1_pos - current_x) + phi * rand(1, D) .* (exemplar2_pos - current_x);
                new_x = current_x + new_v;
                % **位置边界处理 (标准钳制)**
                new_x = max(min(new_x, x_ub), x_lb);
%%                
%                 % 对新位置 new_x 的每个维度进行检查和处理
%                 for dd = 1:D % <--- 遍历当前粒子的每个维度
%                     % 检查是否超出上界
%                     if new_x(dd) > x_ub(dd) % <--- 检查当前粒子当前维度的值
%                         if rand < 0.5 % <--- 50/50 决策应用于当前粒子当前维度
%                             % 50% 概率：钳制到上界
%                             new_x(dd) = x_ub(dd);
%                         else
%                             % 50% 概率：在该维度范围内随机重新初始化
%                             new_x(dd) = x_lb(dd) + (x_ub(dd) - x_lb(dd)) * rand();
%                         end
%                     % 检查是否超出下界 (使用 elseif 或独立的 if 块均可，因为不会同时发生)
%                     elseif new_x(dd) < x_lb(dd) % <--- 检查当前粒子当前维度的值
%                          if rand < 0.5 % <--- 50/50 决策应用于当前粒子当前维度
%                             % 50% 概率：钳制到下界
%                             new_x(dd) = x_lb(dd);
%                         else
%                             % 50% 概率：在该维度范围内随机重新初始化
%                             new_x(dd) = x_lb(dd) + (x_ub(dd) - x_lb(dd)) * rand();
%                         end
%                     end % 结束边界检查
%                 end % 结束维度循环
%%
                % **将更新后的速度和位置保存回全局数组的正确位置**
                v(particle_global_idx, :) = new_v;
                x(particle_global_idx, :) = new_x;

                % 更新适应度
                kp1 = x(particle_global_idx, 1);
                ki1 = x(particle_global_idx, 2);
                kp2 = x(particle_global_idx, 3);
                ki2 = x(particle_global_idx, 4);
                kp3 = x(particle_global_idx, 5);
                ki3 = x(particle_global_idx, 6);

                set_param([mdl '/VOL/Discrete PID Controller3'], 'P', num2str(kp1));
                set_param([mdl '/VOL/Discrete PID Controller3'], 'I', num2str(ki1));
                set_param([mdl '/CIL/Discrete PID Controller1'], 'P', num2str(kp2));
                set_param([mdl '/CIL/Discrete PID Controller1'], 'I', num2str(ki2));
                set_param([mdl '/CIL/Discrete PID Controller2'], 'P', num2str(kp3));
                set_param([mdl '/CIL/Discrete PID Controller2'], 'I', num2str(ki3));
                disp(['[kp1, ki1, kp2, ki2, kp3, ki3]=[', num2str(kp1) ', ' num2str(ki1) ', ' num2str(kp2) ', ' num2str(ki2) ', ' num2str(kp3) ', ' num2str(ki3) ']']);
               
                % 这里也要改
                sim(mdl);
                t = simout1.time(:, 1);                                                                 % get simulation time
                vol = simout1.signals.values(:, 1);                                                     % get load voltage simulation data 
                id = simout2.signals.values(:, 1);                                                     % get inductance current simulation data   
                iq = simout3.signals.values(:, 1);                                                     % get inductance current simulation data   
                fit(particle_global_idx) = evaluation(K1, K2, K3, K4, K5, K6, Vref, PCTvst, Ns, t, vol, id, iq);
            
                disp('=================================================================================');    
            end
        end
        [current_min_fit, current_min_idx] = min(fit);
        % update GBest
        if GBestVal > current_min_fit                 % 寻找全局最优解(种群历史最佳适应度小于当代个体适应度的最大值, 则更新)
            GBestVal = current_min_fit;      % 更新群体历史最佳适应度
            GBest = x(current_min_idx, :);            % 更新群体历史最佳位置
        end
        %计算多样性
        diver(ger) = calculateDiver(x,plimit);
        record_GBestVal_llso(kk, ger) = GBestVal;   % 记录每次迭代的最优适应度值
        disp(' ');
    end 
    record_GBest_llso(:, kk) = GBest';
end

%% display
disp(['[kp1, ki1, kp2, ki2, kp3, ki3]=[', num2str(GBest(1)) ' ,' num2str(GBest(2)) ' ,' num2str(GBest(3)) ' ,' num2str(GBest(4)) ' ,' num2str(GBest(5)) ' ,' num2str(GBest(6)) ']']);

% 记录运行时间
elapsed_time_awllso = toc; % 结束计时，并记录运行时间
disp(['LLSO algorithm elapsed time: ', num2str(elapsed_time_awllso), ' seconds']);

% 保存变量到 .mat 文件
save('llso_results0519.mat', 'record_GBestVal_llso', 'record_GBest_llso','diver');

% 关闭日志记录
% diary off;
%% 多样性计算函数
function diver = calculateDiver(x,plimit)
   N = size(x, 1);
   D = size(plimit, 1);
   % 归一化每个维度到[0,1]
   normalized_x = zeros(N, D);
   for d = 1:D
       min_val = plimit(d, 1);
       max_val = plimit(d, 2);
       normalized_x(:, d) = (x(:, d) - min_val) / (max_val - min_val);
   end
   mean_x = mean(normalized_x, 1);            % 计算归一化后的均值
   diver = (1 / N) * sum(sqrt(sum((normalized_x - mean_x).^2, 2))); % 计算平均欧氏距离
end
%% Function definitions
%函数的作用是在当前层的上一层范围内随机选择两个不同的层级 rl1 和 rl2。是 LLSO 层级学习机制中的核心部分。
function [rl1, rl2] = SelectTwoLevels(max_level)
   if max_level == 1
      rl1 = 1;
      rl2 = 1;
   else
        rl = randperm(max_level, 2);%从 max_level 个层中随机选择两个层（不重复），确保粒子从不同的层中学习。
        rl1 = min(rl);
        rl2 = max(rl);
   end
end
